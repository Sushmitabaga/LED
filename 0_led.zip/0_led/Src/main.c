
#define PERI_BASE                (0x40000000UL)
#define AHB2PERI_OFFSET          (0x08000000UL)
#define AHB2PERI_BASE            (PERI_BASE + AHB2PERI_OFFSET)    //GPIO


#define AHB1PERI_OFFSET          (0x00020000UL)
#define AHB1PERI_BASE            (PERI_BASE + AHB1PERI_OFFSET )

#define RCC_OFFSET               0x1000UL   //RCC is connected to AHB1
#define RCC_AHB1_BASE            (AHB1PERI_BASE  + RCC_OFFSET)    //

#define AHB2EN_R_OFFSET           0x4CUL
#define RCC_AHB2EN_R           (*(volatile unsigned int *)(RCC_AHB1_BASE + AHB2EN_R_OFFSET )) //DOUBT

#define GPIO_OFFSET              (0x0000UL)     //GPIO is connected to AHB1
#define GPIOA_BASE               (AHB2PERI_BASE  +  GPIO_OFFSET )


#define GPIOMODE_OFFSET          0x00UL
#define GPIOA_MODE_R            (*(volatile unsigned int *)(GPIOA_BASE + GPIOMODE_OFFSET  ))

//1U<<10
// &= ~(1U<<11)
#define  ODR_OFFSET               (0x14UL)
#define  GPIOA_ODR_R              (*(volatile unsigned int *)(GPIOA_BASE + ODR_OFFSET ))

#define GPIOEN                   (1U<<0)

#define  PIN5                     (1U<<5)
#define  LED_PIN                   PIN5



int main (void)
{
	//enable clock access
	RCC_AHB2EN_R |= GPIOEN;   //why OR we kept ? because same AHB2 maybe use by others also
	// set PA5 as output pin
	GPIOA_MODE_R  |= (1U<<10 );
	GPIOA_MODE_R  &= ~(1U<<11);
	while(1)
	{
		// SET the LED
		//GPIOA_ODR_R  |=  LED_PIN ;

		//Toggle the LED
		GPIOA_ODR_R  ^=  LED_PIN ;
		for(int i=0;i<100000;i++){}


	}
}
